/**
 * ================================================================
 *  MFR DU NÉRACAIS — API GOOGLE APPS SCRIPT
 *  Application : Mon application MFR du Néracais
 *  Version : 1.0 (Livraison B)
 *  Auteur : Claude AI pour Pascale Daugé, Directrice
 *  Date : 16 mai 2026
 * ================================================================
 *
 *  Ce script transforme une feuille Google Sheets en API
 *  pour l'application MFR du Néracais.
 *
 *  Fonctions exposées :
 *    - login                    : authentification d'un utilisateur
 *    - lister_profils           : récupère la liste d'un type de profil
 *    - creer_profil             : crée un nouveau profil (apprenti, lieu, famille)
 *    - modifier_profil          : modifie un profil existant
 *    - changer_statut           : active / désactive un profil
 *    - reinitialiser_mdp        : génère un nouveau mot de passe
 *    - enregistrer_resultat     : sauvegarde un résultat de test
 *    - lister_resultats         : récupère les résultats des tests
 *
 *  IMPORTANT : ce script doit être déployé en tant qu'application web
 *  accessible à "Tout le monde" pour que l'application puisse l'appeler.
 *  La sécurité est assurée par :
 *    - Un secret partagé (API_SECRET) à renseigner ci-dessous
 *    - Le hachage des mots de passe (SHA-256)
 *    - L'isolement de la feuille Google Sheets (accessible uniquement
 *      aux personnes que vous autorisez explicitement)
 * ================================================================
 */

// =================================================================
// CONFIGURATION — À PERSONNALISER À LA PREMIÈRE INSTALLATION
// =================================================================

/**
 * Secret partagé entre l'application et ce script.
 * Toute requête sans le bon secret est rejetée.
 * IMPORTANT : remplacez la valeur ci-dessous par une chaîne aléatoire
 * d'au moins 20 caractères. Cette même chaîne devra être renseignée
 * dans l'application index.html (variable API_SECRET).
 *
 * Exemple : "MfR-N3rac4is-2026-S3cr3t-x7K9pZqW"
 */
const API_SECRET = "REMPLACER_PAR_VOTRE_SECRET_ALEATOIRE";

// Noms des onglets attendus dans la feuille Google Sheets
const ONGLET_APPRENTIS = "Apprentis";
const ONGLET_LIEUX = "Lieux";
const ONGLET_FAMILLES = "Familles";
const ONGLET_RESULTATS = "Resultats_Tests";
const ONGLET_CONNEXIONS = "Connexions"; // Optionnel - non utilisé en livraison B

// =================================================================
// POINT D'ENTRÉE PRINCIPAL
// =================================================================

/**
 * Reçoit toutes les requêtes POST de l'application.
 * @param {Object} e - Événement Apps Script contenant les données POST
 * @returns {ContentService.TextOutput} - Réponse JSON
 */
function doPost(e) {
  try {
    const params = JSON.parse(e.postData.contents);

    // Vérification du secret partagé
    if (params.secret !== API_SECRET) {
      return repondre({ ok: false, erreur: "Authentification refusée." });
    }

    const action = params.action;

    switch (action) {
      case "login":               return login(params);
      case "lister_profils":      return lister_profils(params);
      case "creer_profil":        return creer_profil(params);
      case "modifier_profil":     return modifier_profil(params);
      case "changer_statut":      return changer_statut(params);
      case "reinitialiser_mdp":   return reinitialiser_mdp(params);
      case "enregistrer_resultat": return enregistrer_resultat(params);
      case "lister_resultats":    return lister_resultats(params);
      case "ping":                return repondre({ ok: true, message: "API opérationnelle" });
      default:                    return repondre({ ok: false, erreur: "Action inconnue : " + action });
    }

  } catch (err) {
    return repondre({ ok: false, erreur: "Erreur serveur : " + err.message });
  }
}

/**
 * Réponse pour les requêtes GET — utilisée pour tester l'API depuis un navigateur.
 */
function doGet(e) {
  return repondre({
    ok: true,
    message: "API MFR du Néracais opérationnelle",
    version: "1.0"
  });
}

// =================================================================
// HELPERS
// =================================================================

/**
 * Construit une réponse JSON propre.
 */
function repondre(objet) {
  return ContentService
    .createTextOutput(JSON.stringify(objet))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Hache un mot de passe avec SHA-256.
 * Un mot de passe en clair n'est jamais stocké dans la feuille.
 */
function hacherMdp(mdp) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    mdp + "MFR_SALT_2026"  // sel constant ajouté avant hachage
  );
  return bytes.map(function(b) {
    return ("0" + (b & 0xff).toString(16)).slice(-2);
  }).join("");
}

/**
 * Récupère l'onglet par son nom, ou le crée s'il n'existe pas.
 */
function getOnglet(nom) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let onglet = ss.getSheetByName(nom);
  if (!onglet) {
    onglet = ss.insertSheet(nom);
    initialiserOnglet(onglet, nom);
  }
  return onglet;
}

/**
 * Crée les en-têtes des onglets si absents.
 */
function initialiserOnglet(onglet, nom) {
  let entetes = [];
  if (nom === ONGLET_APPRENTIS) {
    entetes = ["id", "username", "mdp_hash", "nom", "prenom", "dateNaissance",
               "classe", "dateEntree", "adresse", "telephone", "email",
               "lieuId", "familleId", "statut", "dateCreation", "dateModification"];
  } else if (nom === ONGLET_LIEUX) {
    entetes = ["id", "username", "mdp_hash", "entreprise", "siret", "adresse",
               "telephone", "email", "nomMA", "prenomMA", "telephoneMA", "emailMA",
               "conventionCollective", "statut", "dateCreation", "dateModification"];
  } else if (nom === ONGLET_FAMILLES) {
    entetes = ["id", "username", "mdp_hash", "nom", "prenom", "lienParente",
               "adresse", "telephone", "email", "apprentisIds",
               "statut", "dateCreation", "dateModification"];
  } else if (nom === ONGLET_RESULTATS) {
    entetes = ["id", "timestamp", "username", "nomApprenti", "classe",
               "testId", "titreTest", "scoreGlobal", "scoreTotal",
               "tempsEcoule", "scoresParCompetenceJSON"];
  } else if (nom === ONGLET_CONNEXIONS) {
    entetes = ["timestamp", "username", "role", "resultat", "userAgent"];
  }
  if (entetes.length > 0) {
    onglet.getRange(1, 1, 1, entetes.length).setValues([entetes]);
    onglet.getRange(1, 1, 1, entetes.length)
      .setFontWeight("bold")
      .setBackground("#4F5A2B")
      .setFontColor("#FFFFFF");
    onglet.setFrozenRows(1);
  }
}

/**
 * Convertit toutes les lignes d'un onglet en tableau d'objets.
 */
function lireOnglet(nomOnglet) {
  const onglet = getOnglet(nomOnglet);
  const donnees = onglet.getDataRange().getValues();
  if (donnees.length < 2) return [];

  const entetes = donnees[0];
  const lignes = donnees.slice(1);
  return lignes.map(function(ligne) {
    const obj = {};
    entetes.forEach(function(en, i) {
      obj[en] = ligne[i];
    });
    return obj;
  });
}

/**
 * Trouve la ligne (numéro 1-indexé) d'un id dans un onglet.
 */
function trouverLigneParId(nomOnglet, id) {
  const onglet = getOnglet(nomOnglet);
  const ids = onglet.getRange(2, 1, onglet.getLastRow() - 1 || 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) return i + 2; // +2 car ligne 1 = en-tête, et 1-indexé
  }
  return -1;
}

// =================================================================
// LOGIN
// =================================================================

function login(params) {
  const username = (params.username || "").toLowerCase().trim();
  const mdp = params.password || "";
  const mdpHash = hacherMdp(mdp);

  // Chercher dans les apprentis
  let user = chercherUtilisateur(ONGLET_APPRENTIS, username, mdpHash, "apprenti");
  if (user) return repondre({ ok: true, user: user });

  user = chercherUtilisateur(ONGLET_LIEUX, username, mdpHash, "maitre");
  if (user) return repondre({ ok: true, user: user });

  user = chercherUtilisateur(ONGLET_FAMILLES, username, mdpHash, "parent");
  if (user) return repondre({ ok: true, user: user });

  // Comptes spéciaux MFR (codés en dur pour l'instant — à migrer plus tard)
  // Permet à Pascale et au secrétariat de se connecter même si la feuille
  // est vide au démarrage.
  const comptesMfr = [
    { id: "pascale.dauge", code: "MFR2026", nom: "Pascale Daugé", role: "mfr", classes: "TOUTES" },
    { id: "secretariat",   code: "secret2026", nom: "Secrétariat", role: "mfr", classes: "TOUTES" }
  ];
  const compteMfr = comptesMfr.find(function(c) {
    return c.id === username && c.code === mdp;
  });
  if (compteMfr) {
    return repondre({ ok: true, user: compteMfr });
  }

  return repondre({ ok: false, erreur: "Identifiant ou mot de passe incorrect." });
}

function chercherUtilisateur(nomOnglet, username, mdpHash, role) {
  const utilisateurs = lireOnglet(nomOnglet);
  const match = utilisateurs.find(function(u) {
    return u.username === username
        && u.mdp_hash === mdpHash
        && u.statut === "actif";
  });
  if (!match) return null;

  // Construire l'objet utilisateur retourné à l'application
  const userPublic = {
    id: match.username,
    nom: match.nom + (match.prenom ? " " + match.prenom : ""),
    role: role,
    profilId: match.id  // pour retrouver le profil complet si besoin
  };

  // Adapter selon le rôle
  if (role === "apprenti") {
    userPublic.classes = [match.classe];
    userPublic.nom = (match.prenom || "") + " " + match.nom;
  } else if (role === "maitre") {
    userPublic.entreprise = match.entreprise;
    userPublic.classes = []; // sera complété si besoin
    userPublic.nom = match.entreprise;
  } else if (role === "parent") {
    userPublic.classes = []; // sera complété par recherche des apprentis liés
    userPublic.nom = (match.prenom || "") + " " + match.nom;
  }
  return userPublic;
}

// =================================================================
// LISTER PROFILS
// =================================================================

function lister_profils(params) {
  const type = params.type; // "apprentis" | "lieux" | "familles"
  let nomOnglet;
  if (type === "apprentis") nomOnglet = ONGLET_APPRENTIS;
  else if (type === "lieux") nomOnglet = ONGLET_LIEUX;
  else if (type === "familles") nomOnglet = ONGLET_FAMILLES;
  else return repondre({ ok: false, erreur: "Type inconnu" });

  const profils = lireOnglet(nomOnglet);
  // On retire les hashs de mots de passe avant de renvoyer
  const profilsClean = profils.map(function(p) {
    const copie = {};
    Object.keys(p).forEach(function(k) {
      if (k !== "mdp_hash") copie[k] = p[k];
    });
    return copie;
  });
  return repondre({ ok: true, profils: profilsClean });
}

// =================================================================
// CRÉER PROFIL
// =================================================================

function creer_profil(params) {
  const type = params.type;
  const data = params.data;
  const mdp = params.password;

  if (!data || !mdp) {
    return repondre({ ok: false, erreur: "Données ou mot de passe manquant" });
  }

  let nomOnglet, ligne;

  if (type === "apprenti") {
    nomOnglet = ONGLET_APPRENTIS;
    ligne = [
      data.id, data.username, hacherMdp(mdp), data.nom, data.prenom,
      data.dateNaissance || "", data.classe, data.dateEntree || "",
      data.adresse || "", data.telephone || "", data.email || "",
      data.lieuId || "", data.familleId || "",
      "actif", new Date().toISOString(), ""
    ];
  } else if (type === "lieu") {
    nomOnglet = ONGLET_LIEUX;
    ligne = [
      data.id, data.username, hacherMdp(mdp),
      data.entreprise, data.siret || "", data.adresse || "",
      data.telephone || "", data.email || "",
      data.nomMA, data.prenomMA, data.telephoneMA || "", data.emailMA || "",
      data.conventionCollective || "",
      "actif", new Date().toISOString(), ""
    ];
  } else if (type === "famille") {
    nomOnglet = ONGLET_FAMILLES;
    ligne = [
      data.id, data.username, hacherMdp(mdp),
      data.nom, data.prenom, data.lienParente || "",
      data.adresse || "", data.telephone || "", data.email || "",
      JSON.stringify(data.apprentisIds || []),
      "actif", new Date().toISOString(), ""
    ];
  } else {
    return repondre({ ok: false, erreur: "Type inconnu" });
  }

  const onglet = getOnglet(nomOnglet);
  onglet.appendRow(ligne);
  return repondre({ ok: true, id: data.id });
}

// =================================================================
// MODIFIER PROFIL
// =================================================================

function modifier_profil(params) {
  const type = params.type;
  const id = params.id;
  const data = params.data;

  let nomOnglet;
  if (type === "apprenti") nomOnglet = ONGLET_APPRENTIS;
  else if (type === "lieu") nomOnglet = ONGLET_LIEUX;
  else if (type === "famille") nomOnglet = ONGLET_FAMILLES;
  else return repondre({ ok: false, erreur: "Type inconnu" });

  const numLigne = trouverLigneParId(nomOnglet, id);
  if (numLigne < 0) return repondre({ ok: false, erreur: "Profil introuvable" });

  const onglet = getOnglet(nomOnglet);
  const entetes = onglet.getRange(1, 1, 1, onglet.getLastColumn()).getValues()[0];

  // Mettre à jour uniquement les champs présents dans data (hors mdp et hashs)
  entetes.forEach(function(entete, i) {
    if (entete === "mdp_hash" || entete === "id" || entete === "dateCreation") return;
    if (entete === "dateModification") {
      onglet.getRange(numLigne, i + 1).setValue(new Date().toISOString());
      return;
    }
    if (data.hasOwnProperty(entete)) {
      onglet.getRange(numLigne, i + 1).setValue(data[entete]);
    }
  });

  return repondre({ ok: true });
}

// =================================================================
// CHANGER STATUT (activer / désactiver)
// =================================================================

function changer_statut(params) {
  const type = params.type;
  const id = params.id;
  const nouveauStatut = params.statut; // "actif" ou "desactive"

  let nomOnglet;
  if (type === "apprenti") nomOnglet = ONGLET_APPRENTIS;
  else if (type === "lieu") nomOnglet = ONGLET_LIEUX;
  else if (type === "famille") nomOnglet = ONGLET_FAMILLES;
  else return repondre({ ok: false, erreur: "Type inconnu" });

  const numLigne = trouverLigneParId(nomOnglet, id);
  if (numLigne < 0) return repondre({ ok: false, erreur: "Profil introuvable" });

  const onglet = getOnglet(nomOnglet);
  const entetes = onglet.getRange(1, 1, 1, onglet.getLastColumn()).getValues()[0];
  const colStatut = entetes.indexOf("statut") + 1;
  const colMaj = entetes.indexOf("dateModification") + 1;

  onglet.getRange(numLigne, colStatut).setValue(nouveauStatut);
  if (colMaj > 0) onglet.getRange(numLigne, colMaj).setValue(new Date().toISOString());

  return repondre({ ok: true });
}

// =================================================================
// RÉINITIALISER MOT DE PASSE
// =================================================================

function reinitialiser_mdp(params) {
  const type = params.type;
  const id = params.id;
  const nouveauMdp = params.password;

  if (!nouveauMdp) return repondre({ ok: false, erreur: "Mot de passe manquant" });

  let nomOnglet;
  if (type === "apprenti") nomOnglet = ONGLET_APPRENTIS;
  else if (type === "lieu") nomOnglet = ONGLET_LIEUX;
  else if (type === "famille") nomOnglet = ONGLET_FAMILLES;
  else return repondre({ ok: false, erreur: "Type inconnu" });

  const numLigne = trouverLigneParId(nomOnglet, id);
  if (numLigne < 0) return repondre({ ok: false, erreur: "Profil introuvable" });

  const onglet = getOnglet(nomOnglet);
  const entetes = onglet.getRange(1, 1, 1, onglet.getLastColumn()).getValues()[0];
  const colMdp = entetes.indexOf("mdp_hash") + 1;
  const colMaj = entetes.indexOf("dateModification") + 1;

  onglet.getRange(numLigne, colMdp).setValue(hacherMdp(nouveauMdp));
  if (colMaj > 0) onglet.getRange(numLigne, colMaj).setValue(new Date().toISOString());

  return repondre({ ok: true });
}

// =================================================================
// ENREGISTRER RÉSULTAT DE TEST
// =================================================================

function enregistrer_resultat(params) {
  const r = params.resultat;
  if (!r) return repondre({ ok: false, erreur: "Résultat manquant" });

  const onglet = getOnglet(ONGLET_RESULTATS);
  onglet.appendRow([
    Utilities.getUuid(),
    r.timestamp || new Date().toISOString(),
    r.username || "",
    r.nom || "",
    r.classe || "",
    r.testId || "",
    r.titreTest || "",
    r.scoreGlobal || 0,
    r.scoreTotal || 0,
    r.tempsEcoule || 0,
    JSON.stringify(r.scoresParCompetence || {})
  ]);
  return repondre({ ok: true });
}

// =================================================================
// LISTER RÉSULTATS
// =================================================================

function lister_resultats(params) {
  const resultats = lireOnglet(ONGLET_RESULTATS);
  // Reconstituer le JSON des compétences
  const enrichis = resultats.map(function(r) {
    let scores = {};
    try {
      scores = JSON.parse(r.scoresParCompetenceJSON || "{}");
    } catch (e) {}
    return {
      timestamp: r.timestamp,
      username: r.username,
      nom: r.nomApprenti,
      classe: r.classe,
      testId: r.testId,
      titreTest: r.titreTest,
      scoreGlobal: r.scoreGlobal,
      scoreTotal: r.scoreTotal,
      tempsEcoule: r.tempsEcoule,
      scoresParCompetence: scores
    };
  });
  return repondre({ ok: true, resultats: enrichis });
}

// =================================================================
// FONCTION D'INITIALISATION (à exécuter manuellement une seule fois)
// =================================================================

/**
 * Initialise tous les onglets de la feuille avec les en-têtes corrects.
 * À exécuter UNE SEULE FOIS après l'installation du script.
 * Menu Apps Script : Sélectionner la fonction "initialiser_feuille" → Exécuter.
 */
function initialiser_feuille() {
  getOnglet(ONGLET_APPRENTIS);
  getOnglet(ONGLET_LIEUX);
  getOnglet(ONGLET_FAMILLES);
  getOnglet(ONGLET_RESULTATS);
  // L'onglet Connexions n'est pas créé par défaut (option future)
  SpreadsheetApp.getActiveSpreadsheet().toast(
    "Initialisation terminée. La feuille est prête à être utilisée par l'application.",
    "MFR du Néracais", 8
  );
}

/**
 * Fonction de test simple à exécuter pour vérifier que le script fonctionne.
 * Menu Apps Script : Sélectionner "tester_api" → Exécuter.
 * Vérifiez ensuite le log (View → Logs ou Ctrl+Entrée) pour voir le résultat.
 */
function tester_api() {
  Logger.log("Test 1 : ping");
  Logger.log(doPost({ postData: { contents: JSON.stringify({ secret: API_SECRET, action: "ping" }) } }).getContent());

  Logger.log("Test 2 : lister apprentis");
  Logger.log(doPost({ postData: { contents: JSON.stringify({ secret: API_SECRET, action: "lister_profils", type: "apprentis" }) } }).getContent());

  Logger.log("Test 3 : login avec compte Pascale");
  Logger.log(doPost({ postData: { contents: JSON.stringify({ secret: API_SECRET, action: "login", username: "pascale.dauge", password: "MFR2026" }) } }).getContent());

  SpreadsheetApp.getActiveSpreadsheet().toast(
    "Tests terminés. Consultez les logs (Affichage → Journaux).",
    "MFR du Néracais", 8
  );
}
